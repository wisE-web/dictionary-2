import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
export default class HomeScreen extends React.Component{
  componentDidMount=async()=>{
    var class_ref=await db.ref('/').on('value', data => {
      var all_students =[]
      var class_a = data.val();
      for (var i in class_a) {
        all_students.push(class_a[i]);
      }
      all_students.sort(function(a,b) {
        return a.roll_no - b.roll_no;
      });
      this.setState({all_students: all_students});
    });
  }
  updated
  render(){
    return(
      <View>
      <Text>HomeScreen</Text>
      
      </View>
    )
    
  }
}