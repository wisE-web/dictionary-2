import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
export default class SummaryScreen extends React.Component{
  render(){
    return(
      <View>
      <Text>SummaryScreen</Text>
      </View>
    )
    
  }
}