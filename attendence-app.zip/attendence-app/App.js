import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import {createAppContainer,createSwitchNavigator} from 'react-navigation'
import HomeScreen from './Screens/HomeScreen'
import SummeryScreen from './Screens/SummaryScreen'
export default class App extends React.Component{

  render() {
    return(
      <View>
     <AppContainer/> 
      </View>
    )
  }
}
var AppNavigator= createSwitchNavigator({
  HomeScreen:HomeScreen,
  SummeryScreen:SummeryScreen,
})

const AppContainer = createAppContainer(AppNavigator)