import firebase from 'firebase'

  var firebaseConfig = {
    apiKey: "AIzaSyCUvgxicaSsmYamJ1TyK2RvTYO82jJDzNM",
    authDomain: "attendence-app-641c3.firebaseapp.com",
    databaseURL: "https://attendence-app-641c3-default-rtdb.firebaseio.com",
    projectId: "attendence-app-641c3",
    storageBucket: "attendence-app-641c3.appspot.com",
    messagingSenderId: "943118211548",
    appId: "1:943118211548:web:3b892a247d5a2531ebd719"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  export default firebase.database()